package com.yourname.ohmdream

import android.service.dreams.DreamService
import android.webkit.WebView
import android.webkit.WebViewClient

class OhmDreamService : DreamService() {

    // Change this to your PC's local IP address
    private val dashboardUrl = "http://192.168.1.100:8085"

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isFullscreen = true
        isInteractive = true

        setContentView(R.layout.dream_layout)

        val webView = findViewById<WebView>(R.id.webview)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
        }
        webView.webViewClient = WebViewClient()
        webView.loadUrl(dashboardUrl)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        val webView = findViewById<WebView>(R.id.webview)
        webView.destroy()
    }
}
