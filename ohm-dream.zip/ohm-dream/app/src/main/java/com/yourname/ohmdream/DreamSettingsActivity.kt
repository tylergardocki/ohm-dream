package com.yourname.ohmdream

import android.app.Activity
import android.os.Bundle

// Placeholder settings screen — expand later if you want a URL config UI
class DreamSettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // TODO: add a settings layout with an IP/URL input field
        finish()
    }
}
